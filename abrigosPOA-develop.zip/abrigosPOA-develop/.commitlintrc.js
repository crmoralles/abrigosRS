module.exports = {
  extends: ['@govbr-ds/commitlint-config'],
}
