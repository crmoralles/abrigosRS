export const environment = {
  production: true,
  appCheck: 'TOKEN_HERE',
  firebase: {
    apiKey: 'TOKEN_HERE',
    authDomain: 'ENVIROMENT.firebaseapp.com',
    projectId: 'ENVIROMENT',
    storageBucket: 'ENVIROMENT.appspot.com',
    messagingSenderId: 'NUMBER',
    appId: 'ID_APP',
  },
  serProEndpoint: 'URL',
}
