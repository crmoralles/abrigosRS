export enum TipoDocumentoEnum {
  RG,
  CNH,
  CPF,
  SemDocumento,
}
