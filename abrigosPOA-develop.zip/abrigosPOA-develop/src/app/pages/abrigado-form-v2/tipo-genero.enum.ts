export enum TipoGeneroEnum {
  HOMEM = 'Homem',
  MULHER = 'Mulher',
  NAO_IDENTIFICADO = 'Prefiro não dizer',
}
