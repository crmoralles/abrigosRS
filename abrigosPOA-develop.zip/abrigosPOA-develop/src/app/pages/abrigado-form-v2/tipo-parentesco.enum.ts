export enum TipoParentescoEnum {
  Pai,
  Mae,
  Irmao,
  Filho,
  Conjuge,
  Outro,
}
