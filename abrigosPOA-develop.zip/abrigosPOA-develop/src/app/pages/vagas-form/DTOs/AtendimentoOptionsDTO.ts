export const AtendimentoOptiosnDTO = [
  {
    value: 'Atendimento Médico',
    label: 'Atendimento Médico',
    selected: false,
  },
  {
    value: 'Atendimento de Enfermagem',
    label: 'Atendimento de Enfermagem',
    selected: false,
  },
  {
    value: 'Atendimento Psicológico',
    label: 'Atendimento Psicológico',
    selected: false,
  },
  {
    value: 'Atendimento de Assistência Social',
    label: 'Atendimento de Assistência Social',
    selected: false,
  },
  {
    value: 'Atendimento em Nutrição',
    label: 'Atendimento em Nutrição',
    selected: false,
  },
]
