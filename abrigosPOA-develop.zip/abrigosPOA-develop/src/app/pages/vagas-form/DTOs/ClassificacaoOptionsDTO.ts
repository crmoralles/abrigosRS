export const ClassificacaoOptionsDTO = [
  {
    value: 'Ginásio',
    label: 'Ginásio',
    selected: false,
  },
  {
    value: 'Associação de Moradores',
    label: 'Associação de Moradores',
    selected: false,
  },
  {
    value: 'Associação Empresarial ou Instituição Pública',
    label: 'Associação Empresarial ou Instituição Pública',
    selected: false,
  },
  {
    value: 'Casa',
    label: 'Casa',
    selected: false,
  },
  {
    value: 'Salão de Festas',
    label: 'Salão de Festas',
    selected: false,
  },
  {
    value: 'Restaurante',
    label: 'Restaurante',
    selected: false,
  },
  {
    value: 'Academia de Ginástica',
    label: 'Academia de Ginástica',
    selected: false,
  },
  {
    value: 'Igreja ou Templos',
    label: 'Igreja ou Templos',
    selected: false,
  },
  {
    value: 'Salão Comunitário',
    label: 'Salão Comunitário',
    selected: false,
  },
  {
    value: 'Centro de Tradições Gaúchas',
    label: 'Centro de Tradições Gaúchas',
    selected: false,
  },
  {
    value: 'Organização da Sociedade Civil',
    label: 'Organização da Sociedade Civil',
    selected: false,
  },
  {
    value: 'Sede Campestre de Empresa ou Instituição Pública',
    label: 'Sede Campestre de Empresa ou Instituição Pública',
    selected: false,
  },
  {
    value: 'Outro',
    label: 'Outro',
    selected: false,
  },
]
