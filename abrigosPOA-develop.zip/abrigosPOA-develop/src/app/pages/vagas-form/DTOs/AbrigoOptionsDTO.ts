export const AbrigoOptionsDTO = [
  {
    value: 'Abrigo Rede Prefeitura',
    label: 'Abrigo Rede Prefeitura',
    selected: false,
  },
  {
    value: 'Abrigo Terceirizado',
    label: 'Abrigo Terceirizado',
    selected: false,
  },
  {
    value: 'Abrigo Referenciado',
    label: 'Abrigo Referenciado',
    selected: false,
  },
  {
    value: 'Abrigo Parceiro',
    label: 'Abrigo Parceiro',
    selected: false,
  },
]
