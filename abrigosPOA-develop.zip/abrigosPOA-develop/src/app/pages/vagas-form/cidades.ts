export const cidades = [
  {
    value: 'Alvorada',
    label: 'Alvorada',
    selected: false,
  },
  {
    value: 'Porto Alegre',
    label: 'Porto Alegre',
    selected: true,
  },
  {
    value: 'São Leopoldo',
    label: 'São Leopoldo',
    selected: false,
  },
  {
    value: 'Viamão',
    label: 'Viamão',
    selected: false,
  },
  {
    value: 'Cachoeirinha',
    label: 'Cachoeirinha',
    selected: false,
  },
  {
    value: 'Gravataí',
    label: 'Gravataí',
    selected: false,
  },
  {
    value: 'Canoas',
    label: 'Canoas',
    selected: false,
  },
  {
    value: 'Eldorado do Sul',
    label: 'Eldorado do Sul',
    selected: false,
  },
  {
    value: 'Guaíba',
    label: 'Guaíba',
    selected: false,
  },
  {
    value: 'Novo Hamburgo',
    label: 'Novo Hamburgo',
    selected: false,
  },
  {
    value: 'Caxias do Sul',
    label: 'Caxias do Sul',
    selected: false,
  },
  {
    value: 'Bento Gonçalves',
    label: 'Bento Gonçalves',
    selected: false,
  },
  {
    value: 'Lajeado',
    label: 'Lajeado',
    selected: false,
  },
]
